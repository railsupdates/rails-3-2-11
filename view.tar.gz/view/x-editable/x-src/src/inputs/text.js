/**
Text input

@class text
@extends abstractinput
@final
@example
<a href="#" id="username" data-type="text" data-pk="1">awesome</a>
<script>
$(function(){
    $('#username').editable({
        url: '/post',
        title: 'Enter username'
    });
});
</script>
**/
(function ($) {
    var Text = function (options) {
        this.init('text', options, Text.defaults);
    };

    $.fn.editableutils.inherit(Text, $.fn.editabletypes.abstractinput);

    $.extend(Text.prototype, {
        render: function() {
           this.renderClear();
           this.setClass();
           this.setAttr('placeholder');
        },
        
        activate: function() {
            if(this.$input.is(':visible')) {
                this.$input.focus();
                $.fn.editableutils.setCursorPosition(this.$input.get(0), this.$input.val().length);
                if(this.toggleClear) {
                    this.toggleClear();
                }
            }
        },
        
        //render clear button
        renderClear:  function() {
           if (this.options.clear) {
               this.$clear = $('<span class="editable-clear-x"></span>');
               this.$input.after(this.$clear)
                          .css('padding-right', 20)
                          .keyup($.proxy(this.toggleClear, this))
                          .parent().css('position', 'relative');
                          
               this.$clear.click($.proxy(function(){
                   this.$clear.hide();
                   this.$input.val('').focus();
               }, this));                       
           }            
        },
        
        postrender: function() {
            if(this.$clear) {
                //can position clear button only here, when form is shown and height can be calculated
                var h = this.$input.outerHeight() || 20,
                    delta = (h - this.$clear.height()) / 2;
                
                //workaround for plain-popup  
                if(delta < 3) {
                   delta = 3; 
                }
                    
                this.$clear.css({top: delta, right: delta});
            } 
        },
        
        //show / hide clear button
        toggleClear: function() {
            if(!this.$clear) {
                return;
            }
            
            if(this.$input.val()) {
                this.$clear.show();
            } else {
                this.$clear.hide();
            } 
        }  
    });

    Text.defaults = $.extend({}, $.fn.editabletypes.abstractinput.defaults, {
        /**
        @property tpl 
        @default <input type="text">
        **/         
        tpl: '<input type="text">',
        /**
        Placeholder attribute of input. Shown when input is empty.

        @property placeholder 
        @type string
        @default null
        **/             
        placeholder: null,
        
        /**
        Whether to show `clear` button 
        
        @property clear 
        @type boolean
        @default true        
        **/
        clear: true
    });

    $.fn.editabletypes.text = Text;

}(window.jQuery));
