$(function(){
    prettyPrint();
});